"""
Создаёт zip-архив исходников проекта в корне репозитория (без venv, __pycache__, .git).
Запуск из корня: python tools/make_code_backup_zip.py
"""

from __future__ import annotations

import time
import zipfile
from pathlib import Path

SKIP_DIR_NAMES = frozenset(
    {"__pycache__", ".git", ".pytest_cache", "venv", ".venv", "node_modules"}
)


def main() -> Path:
    root = Path(__file__).resolve().parents[1]
    stamp = time.strftime("%Y%m%d-%H%M%S")
    out = root / f"MySuperBot-code-backup-{stamp}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            if any(part in SKIP_DIR_NAMES for part in path.parts):
                continue
            arc = path.relative_to(root)
            zf.write(path, arc)
    return out


if __name__ == "__main__":
    p = main()
    print(p)
