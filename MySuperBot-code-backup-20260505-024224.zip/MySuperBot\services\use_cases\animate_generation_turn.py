"""Use-case: оживление фото — списание энергии и постановка ``fire_animate_job``."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from config import Settings
from services.generation_jobs import fire_animate_job
from services.repository import try_consume_energy

if TYPE_CHECKING:
    from aiogram import Bot


class AnimateGenOutcome(str, Enum):
    INSUFFICIENT_BALANCE = "insufficient_balance"
    SUCCESS = "success"


@dataclass(frozen=True)
class AnimateGenResult:
    outcome: AnimateGenOutcome


async def run_animate_generation_turn(
    settings: Settings, bot: "Bot", chat_id: int, user_id: int
) -> AnimateGenResult:
    """
    Вход: settings, bot, chat_id, user_id (фото уже принято хендлером).
    Возвращает: ``AnimateGenResult``; при SUCCESS задача поставлена.
    """
    if not await try_consume_energy(user_id, settings.cost_animate):
        return AnimateGenResult(outcome=AnimateGenOutcome.INSUFFICIENT_BALANCE)
    fire_animate_job(bot, chat_id, user_id)
    return AnimateGenResult(outcome=AnimateGenOutcome.SUCCESS)
