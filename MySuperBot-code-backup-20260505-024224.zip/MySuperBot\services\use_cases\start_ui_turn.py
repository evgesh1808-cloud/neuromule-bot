"""
UI-настройки для ответов ``/start`` без привязки к конкретному хендлеру.

Отдельный модуль, чтобы в ``telegram_bot`` не плодить ``LinkPreviewOptions(is_disabled=True)``.
"""

from __future__ import annotations

from aiogram.types import LinkPreviewOptions


def start_messages_link_preview_off() -> LinkPreviewOptions:
    """Отключает превью ссылок в стартовых сообщениях (канал, приветствие)."""
    return LinkPreviewOptions(is_disabled=True)
