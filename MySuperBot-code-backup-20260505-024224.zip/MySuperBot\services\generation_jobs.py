"""Асинхронные «задачи генерации»: статус сразу, результат позже (заглушка под реальный API)."""
from __future__ import annotations

import asyncio
import base64
import logging
from typing import TYPE_CHECKING, Literal

from aiogram.types import BufferedInputFile

from config import settings
from content import messages as msg
from content.inline_keyboards import result_music_keyboard, result_photo_keyboard, result_video_keyboard
from services.repository import get_user_row, rollback_daily_photo_slot, update_balance

if TYPE_CHECKING:
    from aiogram import Bot

logger = logging.getLogger(__name__)

# Минимальный PNG для заглушки результата (реальный API подставит своё медиа).
_MINI_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)

JobKind = Literal["photo", "video", "music", "animate"]


def _balance_footer(energy: int) -> str:
    if energy < settings.energy_low_threshold:
        return msg.TXT_BALANCE_LOW_FOOTER
    return ""


async def _photo_stub_worker(
    bot: "Bot",
    chat_id: int,
    user_id: int,
    model_label: str,
    user_prompt: str,
    used_daily_slot: bool,
) -> None:
    try:
        await asyncio.sleep(2.0)
        row = await get_user_row(user_id)
        cap = msg.TXT_RESULT_PHOTO_CAPTION.format(
            cost=settings.cost_photo,
            balance=row.energy,
            animate_cost=settings.cost_animate_video_suggest,
        )
        cap += _balance_footer(row.energy)
        photo = BufferedInputFile(_MINI_PNG, filename="neuromule_preview.png")
        await bot.send_photo(
            chat_id,
            photo=photo,
            caption=cap,
            reply_markup=result_photo_keyboard(),
        )
    except Exception:
        logger.exception("photo job failed")
        await update_balance(user_id, "energy", settings.cost_photo)
        if used_daily_slot:
            await rollback_daily_photo_slot(user_id)
        try:
            await bot.send_message(chat_id, msg.TXT_GEN_JOB_FAILED)
        except Exception:
            pass


async def _video_stub_worker(bot: "Bot", chat_id: int, user_id: int) -> None:
    try:
        await asyncio.sleep(2.0)
        row = await get_user_row(user_id)
        cap = msg.TXT_RESULT_VIDEO_CAPTION.format(cost=settings.cost_video)
        cap += _balance_footer(row.energy)
        await bot.send_message(chat_id, cap, reply_markup=result_video_keyboard())
    except Exception:
        logger.exception("video job failed")
        await update_balance(user_id, "energy", settings.cost_video)
        try:
            await bot.send_message(chat_id, msg.TXT_GEN_JOB_FAILED)
        except Exception:
            pass


async def _music_stub_worker(bot: "Bot", chat_id: int, user_id: int, style_hint: str) -> None:
    try:
        await asyncio.sleep(2.0)
        row = await get_user_row(user_id)
        style = style_hint[:120] if style_hint else "по запросу"
        cap = msg.TXT_RESULT_MUSIC_CAPTION.format(
            style=style,
            balance=row.energy,
        )
        cap += _balance_footer(row.energy)
        await bot.send_message(chat_id, cap, reply_markup=result_music_keyboard())
    except Exception:
        logger.exception("music job failed")
        await update_balance(user_id, "energy", settings.cost_music)
        try:
            await bot.send_message(chat_id, msg.TXT_GEN_JOB_FAILED)
        except Exception:
            pass


async def _animate_stub_worker(bot: "Bot", chat_id: int, user_id: int) -> None:
    try:
        await asyncio.sleep(2.0)
        row = await get_user_row(user_id)
        cap = msg.TXT_RESULT_ANIMATE_CAPTION.format(
            cost=settings.cost_animate,
            balance=row.energy,
        )
        cap += _balance_footer(row.energy)
        await bot.send_message(chat_id, cap)
    except Exception:
        logger.exception("animate job failed")
        await update_balance(user_id, "energy", settings.cost_animate)
        try:
            await bot.send_message(chat_id, msg.TXT_GEN_JOB_FAILED)
        except Exception:
            pass


def fire_photo_job(
    bot: "Bot",
    chat_id: int,
    user_id: int,
    model_label: str,
    user_prompt: str,
    used_daily_slot: bool,
) -> None:
    asyncio.create_task(
        _photo_stub_worker(bot, chat_id, user_id, model_label, user_prompt, used_daily_slot)
    )


def fire_video_job(bot: "Bot", chat_id: int, user_id: int) -> None:
    asyncio.create_task(_video_stub_worker(bot, chat_id, user_id))


def fire_music_job(bot: "Bot", chat_id: int, user_id: int, style_hint: str) -> None:
    asyncio.create_task(_music_stub_worker(bot, chat_id, user_id, style_hint))


def fire_animate_job(bot: "Bot", chat_id: int, user_id: int) -> None:
    asyncio.create_task(_animate_stub_worker(bot, chat_id, user_id))
