"""SQLite через aiosqlite: пользователи, рефералы, лимиты, промокоды, диалог, платежи."""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from datetime import date, datetime, timezone
from pathlib import Path

import aiosqlite

DB_PATH = str(Path(__file__).resolve().parent.parent / "neuromule_base.db")


async def _migrate_users(db: aiosqlite.Connection) -> None:
    async with db.execute("PRAGMA table_info(users)") as cur:
        rows = await cur.fetchall()
    cols = {row[1] for row in rows}
    alters = [
        ("tariff", "ALTER TABLE users ADD COLUMN tariff TEXT DEFAULT 'Free'"),
        ("referred_by", "ALTER TABLE users ADD COLUMN referred_by INTEGER"),
        ("photo_daily_date", "ALTER TABLE users ADD COLUMN photo_daily_date TEXT"),
        ("photo_daily_count", "ALTER TABLE users ADD COLUMN photo_daily_count INTEGER DEFAULT 0"),
        ("username", "ALTER TABLE users ADD COLUMN username TEXT"),
        ("persistent_memory", "ALTER TABLE users ADD COLUMN persistent_memory TEXT"),
    ]
    for name, ddl in alters:
        if name not in cols:
            await db.execute(ddl)


async def _migrate_rate_limit_hits(db: aiosqlite.Connection) -> None:
    await db.execute(
        """
        CREATE TABLE IF NOT EXISTS rate_limit_hits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            ts REAL NOT NULL
        )
        """
    )
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_rate_limit_hits_user_ts ON rate_limit_hits (user_id, ts)"
    )


async def _migrate_dialog_messages(db: aiosqlite.Connection) -> None:
    await db.execute(
        """
        CREATE TABLE IF NOT EXISTS dialog_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
    )
    await db.execute(
        "CREATE INDEX IF NOT EXISTS idx_dialog_messages_user_created "
        "ON dialog_messages (user_id, created_at)"
    )


async def _seed_promos(db: aiosqlite.Connection, promo_seeds: str) -> None:
    if not promo_seeds.strip():
        return
    for part in promo_seeds.split(","):
        part = part.strip()
        if not part or ":" not in part:
            continue
        bits = part.split(":")
        if len(bits) != 3:
            continue
        code, bonus_s, max_s = bits[0].strip().upper(), bits[1].strip(), bits[2].strip()
        try:
            bonus = int(bonus_s)
            max_u = int(max_s)
        except ValueError:
            continue
        await db.execute(
            "INSERT OR IGNORE INTO promo_codes (code, energy_bonus, max_uses, uses_count) VALUES (?, ?, ?, 0)",
            (code, bonus, max_u),
        )


async def init_db(promo_seeds: str = "") -> None:
    """Создаёт таблицы, миграции и сиды промокодов. Вызывать при старте приложения."""
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA journal_mode=WAL")
        await db.execute("PRAGMA foreign_keys=ON")
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                energy INTEGER DEFAULT 20,
                crystals INTEGER DEFAULT 30,
                tariff TEXT DEFAULT 'Free',
                referred_by INTEGER,
                photo_daily_date TEXT,
                photo_daily_count INTEGER DEFAULT 0
            )
            """
        )
        await _migrate_users(db)
        await _migrate_dialog_messages(db)
        await _migrate_rate_limit_hits(db)
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS referrals (
                invited_id INTEGER PRIMARY KEY,
                inviter_id INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS promo_codes (
                code TEXT PRIMARY KEY,
                energy_bonus INTEGER NOT NULL,
                max_uses INTEGER NOT NULL,
                uses_count INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS promo_redemptions (
                user_id INTEGER NOT NULL,
                code TEXT NOT NULL,
                redeemed_at TEXT NOT NULL,
                PRIMARY KEY (user_id, code)
            )
            """
        )
        await db.execute(
            """
            CREATE TABLE IF NOT EXISTS payment_charges (
                charge_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                energy_added INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
            """
        )
        await _seed_promos(db, promo_seeds)
        await db.commit()


@dataclass(frozen=True)
class UserRow:
    id: int
    energy: int
    crystals: int
    tariff: str
    referred_by: int | None
    photo_daily_date: str | None
    photo_daily_count: int


async def ensure_user(user_id: int, username: str | None = None) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT id FROM users WHERE id = ?", (user_id,)) as cur:
            exists = await cur.fetchone()
        if not exists:
            await db.execute(
                """
                INSERT INTO users (id, energy, crystals, tariff, referred_by, photo_daily_date, photo_daily_count)
                VALUES (?, 20, 30, 'Free', NULL, NULL, 0)
                """,
                (user_id,),
            )
        if username is not None:
            u = username.strip()[:255] if username else ""
            await db.execute("UPDATE users SET username = ? WHERE id = ?", (u or None, user_id))
        await db.commit()


async def get_user_row(user_id: int) -> UserRow:
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """
            SELECT id, energy, crystals, tariff, referred_by, photo_daily_date, photo_daily_count
            FROM users WHERE id = ?
            """,
            (user_id,),
        ) as cur:
            row = await cur.fetchone()
    return UserRow(
        id=int(row[0]),
        energy=int(row[1]),
        crystals=int(row[2]),
        tariff=str(row[3] or "Free"),
        referred_by=int(row[4]) if row[4] is not None else None,
        photo_daily_date=row[5],
        photo_daily_count=int(row[6] or 0),
    )


async def try_set_referrer(invited_id: int, inviter_id: int) -> bool:
    if invited_id == inviter_id:
        return False
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT referred_by FROM users WHERE id = ?", (invited_id,)) as cur:
            r = await cur.fetchone()
        if not r or r[0] is not None:
            return False
        async with db.execute("SELECT 1 FROM referrals WHERE invited_id = ?", (invited_id,)) as cur:
            if await cur.fetchone():
                return False
        await db.execute("UPDATE users SET referred_by = ? WHERE id = ?", (inviter_id, invited_id))
        await db.execute(
            "INSERT INTO referrals (invited_id, inviter_id, created_at) VALUES (?, ?, ?)",
            (invited_id, inviter_id, date.today().isoformat()),
        )
        await db.commit()
    return True


async def referrals_count(inviter_id: int) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM referrals WHERE inviter_id = ?", (inviter_id,)) as cur:
            row = await cur.fetchone()
    return int(row[0])


async def get_balances(user_id: int) -> tuple[int, int]:
    row = await get_user_row(user_id)
    return row.energy, row.crystals


async def update_balance(user_id: int, field: str, delta: int) -> None:
    if field not in {"energy", "crystals"}:
        raise ValueError("Invalid field")
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE users SET {field} = {field} + ? WHERE id = ?", (delta, user_id))
        await db.commit()


async def try_consume_energy(user_id: int, amount: int) -> bool:
    if amount <= 0:
        return True
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "UPDATE users SET energy = energy - ? WHERE id = ? AND energy >= ?",
            (amount, user_id, amount),
        )
        await db.commit()
        return cur.rowcount == 1


async def try_consume_daily_photo_slot(user_id: int, daily_limit: int) -> tuple[bool, int]:
    await ensure_user(user_id)
    today = date.today().isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT photo_daily_date, photo_daily_count FROM users WHERE id = ?",
            (user_id,),
        ) as cur:
            row = await cur.fetchone()
        d, c = row[0], row[1]
        count = int(c or 0)
        if d != today:
            count = 0
            await db.execute(
                "UPDATE users SET photo_daily_date = ?, photo_daily_count = 0 WHERE id = ?",
                (today, user_id),
            )
        if count >= daily_limit:
            await db.commit()
            return False, count
        await db.execute(
            "UPDATE users SET photo_daily_date = ?, photo_daily_count = ? WHERE id = ?",
            (today, count + 1, user_id),
        )
        await db.commit()
        return True, count + 1


async def rollback_daily_photo_slot(user_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            UPDATE users SET photo_daily_count = CASE WHEN photo_daily_count > 0 THEN photo_daily_count - 1 ELSE 0 END
            WHERE id = ?
            """,
            (user_id,),
        )
        await db.commit()


async def try_redeem_promo(user_id: int, raw_code: str) -> tuple[bool, str, int]:
    await ensure_user(user_id)
    code = (raw_code or "").strip().upper()
    if not code:
        return False, "unknown", 0
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT energy_bonus, max_uses, uses_count FROM promo_codes WHERE code = ?",
            (code,),
        ) as cur:
            row = await cur.fetchone()
        if not row:
            return False, "unknown", 0
        bonus, max_uses, uses = int(row[0]), int(row[1]), int(row[2])
        async with db.execute(
            "SELECT 1 FROM promo_redemptions WHERE user_id = ? AND code = ?",
            (user_id, code),
        ) as cur:
            if await cur.fetchone():
                return False, "used", 0
        if uses >= max_uses:
            return False, "exhausted", 0
        await db.execute(
            "INSERT INTO promo_redemptions (user_id, code, redeemed_at) VALUES (?, ?, ?)",
            (user_id, code, date.today().isoformat()),
        )
        await db.execute("UPDATE promo_codes SET uses_count = uses_count + 1 WHERE code = ?", (code,))
        await db.execute("UPDATE users SET energy = energy + ? WHERE id = ?", (bonus, user_id))
        await db.commit()
    return True, "redeemed", bonus


async def dialog_append(user_id: int, role: str, content: str) -> None:
    if role not in ("user", "assistant"):
        raise ValueError("role must be 'user' or 'assistant'")
    await ensure_user(user_id)
    ts = datetime.now(timezone.utc).isoformat()
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO dialog_messages (user_id, role, content, created_at) VALUES (?, ?, ?, ?)",
            (user_id, role, content, ts),
        )
        await db.commit()


async def dialog_fetch_last(user_id: int, limit: int) -> list[tuple[str, str]]:
    if limit <= 0:
        return []
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """
            SELECT role, content FROM dialog_messages
            WHERE user_id = ?
            ORDER BY datetime(created_at) DESC, id DESC
            LIMIT ?
            """,
            (user_id, limit),
        ) as cur:
            rows = list(await cur.fetchall())
    rows.reverse()
    return [(str(r[0]), str(r[1])) for r in rows]


async def dialog_total_messages(user_id: int) -> int:
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT COUNT(*) FROM dialog_messages WHERE user_id = ?", (user_id,)) as cur:
            row = await cur.fetchone()
    return int(row[0])


async def dialog_pop_last_for_user(user_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            DELETE FROM dialog_messages
            WHERE id = (
                SELECT id FROM dialog_messages
                WHERE user_id = ?
                ORDER BY datetime(created_at) DESC, id DESC
                LIMIT 1
            )
            """,
            (user_id,),
        )
        await db.commit()


async def dialog_prune_keep_last(user_id: int, keep: int) -> None:
    if keep <= 0:
        return
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT id FROM dialog_messages WHERE user_id = ? ORDER BY datetime(created_at) ASC, id ASC",
            (user_id,),
        ) as cur:
            rows = await cur.fetchall()
        ids = [int(r[0]) for r in rows]
        if len(ids) <= keep:
            return
        to_delete = ids[: len(ids) - keep]
        await db.executemany("DELETE FROM dialog_messages WHERE id = ?", [(i,) for i in to_delete])
        await db.commit()


async def get_persistent_memory(user_id: int) -> str | None:
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT persistent_memory FROM users WHERE id = ?", (user_id,)) as cur:
            row = await cur.fetchone()
    if not row or row[0] is None:
        return None
    s = str(row[0]).strip()
    return s or None


async def set_persistent_memory(user_id: int, text: str | None) -> None:
    await ensure_user(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET persistent_memory = ? WHERE id = ?", (text, user_id))
        await db.commit()


async def clear_user_dialog_and_memory(user_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM dialog_messages WHERE user_id = ?", (user_id,))
        await db.execute("UPDATE users SET persistent_memory = NULL WHERE id = ?", (user_id,))
        await db.commit()


async def rate_limit_allow(user_id: int, max_per_minute: int) -> bool:
    """Скользящее окно ~60 с по ``time.time()``; записи старше окна удаляются."""
    import time as _time

    if max_per_minute <= 0:
        return True
    now = _time.time()
    cutoff = now - 60.0
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM rate_limit_hits WHERE ts < ?", (cutoff,))
        async with db.execute(
            "SELECT COUNT(*) FROM rate_limit_hits WHERE user_id = ? AND ts >= ?",
            (user_id, cutoff),
        ) as cur:
            row = await cur.fetchone()
        n = int(row[0]) if row else 0
        if n >= max_per_minute:
            await db.commit()
            return False
        await db.execute("INSERT INTO rate_limit_hits (user_id, ts) VALUES (?, ?)", (user_id, now))
        await db.commit()
    return True


async def rate_limit_rollback_last(user_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """
            DELETE FROM rate_limit_hits WHERE id = (
                SELECT id FROM rate_limit_hits WHERE user_id = ?
                ORDER BY id DESC LIMIT 1
            )
            """,
            (user_id,),
        )
        await db.commit()


async def claim_payment_charge(charge_id: str, user_id: int, energy_added: int) -> bool:
    if not charge_id:
        return False
    try:
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                """
                INSERT INTO payment_charges (charge_id, user_id, energy_added, created_at)
                VALUES (?, ?, ?, ?)
                """,
                (charge_id, user_id, energy_added, date.today().isoformat()),
            )
            await db.commit()
        return True
    except sqlite3.IntegrityError:
        return False
