"""Use-case: текстовый промпт для видео — списание энергии и постановка ``fire_video_job``."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from config import Settings
from services.generation_jobs import fire_video_job
from services.repository import try_consume_energy

if TYPE_CHECKING:
    from aiogram import Bot


class VideoGenOutcome(str, Enum):
    NEED_PROMPT = "need_prompt"
    INSUFFICIENT_BALANCE = "insufficient_balance"
    SUCCESS = "success"


@dataclass(frozen=True)
class VideoGenResult:
    outcome: VideoGenOutcome


async def run_video_generation_turn(
    settings: Settings,
    bot: "Bot",
    chat_id: int,
    user_id: int,
    prompt: str,
) -> VideoGenResult:
    """
    Вход: settings, bot, chat_id, user_id, prompt (уже strip).
    Возвращает: ``VideoGenResult``; при SUCCESS задача поставлена.
    """
    if not prompt:
        return VideoGenResult(outcome=VideoGenOutcome.NEED_PROMPT)
    if not await try_consume_energy(user_id, settings.cost_video):
        return VideoGenResult(outcome=VideoGenOutcome.INSUFFICIENT_BALANCE)
    fire_video_job(bot, chat_id, user_id)
    return VideoGenResult(outcome=VideoGenOutcome.SUCCESS)
