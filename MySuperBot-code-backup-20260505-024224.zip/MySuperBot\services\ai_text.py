"""
Асинхронные вызовы OpenRouter (Chat Completions).

Каждый запрос передаёт ``max_tokens`` из конфига (ограничение стоимости ответа).
При переданном ``stream_callback`` включается режим SSE: текст накапливается по дельтам для live-редактирования в Telegram.
"""

from __future__ import annotations

import json
import logging
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Awaitable, Callable

import httpx

from config import Settings

logger = logging.getLogger(__name__)

# Колбэк стриминга: (накопленный_текст, завершено_ли_сообщение).
StreamCallback = Callable[[str, bool], Awaitable[None]]


def _estimate_messages_chars(messages: list[dict[str, Any]]) -> int:
    """Суммирует длину полей content — грубая защита от гигантского JSON."""
    n = 0
    for m in messages:
        n += len(str(m.get("content", "")))
    return n


def _estimate_messages_prompt_tokens_chars(messages: list[dict[str, Any]], char_per_token: int) -> int:
    if char_per_token <= 0:
        char_per_token = 3
    total = 0
    for m in messages:
        total += len(str(m.get("content", ""))) // char_per_token
    return total


def _message_content_as_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                t = item.get("text")
                if isinstance(t, str):
                    parts.append(t)
        return "".join(parts)
    return str(content)


def estimate_messages_prompt_tokens(
    messages: list[dict[str, Any]],
    *,
    settings: Settings | None = None,
    char_per_token: int | None = None,
) -> int:
    """
    Оценка входных токенов: при ``settings.chat_use_tiktoken`` — tiktoken по тексту ролей и content;
    иначе сумма ``len(content)//char_per_token`` (эвристика для кириллицы и т.п.).
    """
    cpt = char_per_token if char_per_token is not None else (settings.chat_char_per_token_est if settings else 3)
    if settings is not None and settings.chat_use_tiktoken:
        try:
            import tiktoken

            try:
                enc = tiktoken.encoding_for_model("gpt-3.5-turbo")
            except Exception:
                enc = tiktoken.get_encoding(settings.tiktoken_encoding)
            tokens_per_message = 3
            tokens_per_name = 1
            n = 0
            for m in messages:
                n += tokens_per_message
                for key, value in m.items():
                    if key == "content":
                        val = _message_content_as_text(value)
                    else:
                        val = value
                    n += len(enc.encode(str(val)))
                    if key == "name":
                        n += tokens_per_name
            n += 3
            return n
        except Exception:
            logger.debug("tiktoken count failed, using char heuristic", exc_info=True)
    return _estimate_messages_prompt_tokens_chars(messages, cpt)


@asynccontextmanager
async def _http_client_scope(
    http_client: httpx.AsyncClient | None,
) -> AsyncIterator[httpx.AsyncClient]:
    """Отдаёт переданный клиент или создаёт временный ``AsyncClient`` и закрывает его по выходу."""
    if http_client is not None:
        yield http_client
        return
    async with httpx.AsyncClient() as client:
        yield client


def _chat_headers(settings: Settings) -> dict[str, str]:
    """Заголовки авторизации для OpenRouter (Bearer + JSON)."""
    return {
        "Authorization": f"Bearer {settings.openrouter_key}",
        "Content-Type": "application/json",
    }


def _chat_payload(
    settings: Settings,
    model: str,
    messages: list[dict[str, Any]],
    *,
    stream: bool,
) -> dict[str, Any]:
    """
    Собирает тело POST /chat/completions: модель, сообщения, ``max_tokens``, опционально ``stream``.

    ``max_tokens`` всегда из настроек — единый рубильник расхода на ответ модели.
    """
    body: dict[str, Any] = {
        "model": model,
        "messages": messages,
        "max_tokens": settings.openrouter_max_output_tokens,
    }
    if stream:
        body["stream"] = True
    return body


async def _post_chat_completion(
    client: httpx.AsyncClient,
    settings: Settings,
    model: str,
    messages: list[dict[str, Any]],
    *,
    timeout: float,
) -> str | None:
    """Один нестриминговый запрос; при HTTP≠200 или пустом content возвращает ``None``."""
    payload = _chat_payload(settings, model, messages, stream=False)
    response = await client.post(
        settings.openrouter_chat_url,
        headers=_chat_headers(settings),
        json=payload,
        timeout=timeout,
    )
    if response.status_code != 200:
        logger.warning(
            "OpenRouter model=%s status=%s body=%s",
            model,
            response.status_code,
            response.text[:500],
        )
        return None
    data = response.json()
    content = data["choices"][0]["message"]["content"]
    if not isinstance(content, str):
        return None
    return content


def _stream_delta_text(piece: Any) -> str:
    """Текст из ``delta.content`` (строка, список фрагментов OpenAI/OpenRouter)."""
    if piece is None:
        return ""
    if isinstance(piece, str):
        return piece
    if isinstance(piece, list):
        parts: list[str] = []
        for item in piece:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                t = item.get("text")
                if isinstance(t, str):
                    parts.append(t)
        return "".join(parts)
    return str(piece)


async def _iter_sse_data_payloads(resp: httpx.Response) -> AsyncIterator[str]:
    """
    Разбор SSE по байтам (устойчиво к разбиению чанков TCP): строки ``data:...``,
    комментарии ``:``, пустые строки — пропуск.
    """
    buf = b""
    async for chunk in resp.aiter_bytes():
        buf += chunk
        while True:
            nl = buf.find(b"\n")
            if nl == -1:
                break
            line_b, buf = buf[:nl], buf[nl + 1 :]
            line = line_b.decode("utf-8", errors="replace").rstrip("\r")
            if not line:
                continue
            if line.startswith(":"):
                continue
            if not line.startswith("data:"):
                continue
            yield line[5:].lstrip()


async def _post_chat_completion_stream(
    client: httpx.AsyncClient,
    settings: Settings,
    model: str,
    messages: list[dict[str, Any]],
    *,
    timeout: float,
    stream_callback: StreamCallback,
) -> str | None:
    """
    Стриминговый запрос (SSE): ``data:`` по байтам, ``delta.content``, колбэк с частичным текстом.
    """
    payload = _chat_payload(settings, model, messages, stream=True)
    acc = ""
    try:
        async with client.stream(
            "POST",
            settings.openrouter_chat_url,
            headers=_chat_headers(settings),
            json=payload,
            timeout=timeout,
        ) as resp:
            if resp.status_code != 200:
                body = (await resp.aread())[:800]
                logger.warning(
                    "OpenRouter stream model=%s status=%s body=%s",
                    model,
                    resp.status_code,
                    body,
                )
                return None
            async for raw in _iter_sse_data_payloads(resp):
                if raw == "[DONE]":
                    if acc:
                        await stream_callback(acc, True)
                    return acc or None
                try:
                    obj = json.loads(raw)
                except json.JSONDecodeError:
                    logger.debug("OpenRouter stream skip bad JSON: %s", raw[:200])
                    continue
                for ch in obj.get("choices") or []:
                    delta = ch.get("delta") or {}
                    piece = _stream_delta_text(delta.get("content"))
                    if piece:
                        acc += piece
                        await stream_callback(acc, False)
            if acc:
                await stream_callback(acc, True)
            return acc or None
    except Exception:
        logger.exception("OpenRouter stream model=%s failed", model)
        if acc:
            try:
                await stream_callback(acc, True)
            except Exception:
                logger.debug("stream_callback on error failed", exc_info=True)
        return None


async def ask_ai_messages(
    settings: Settings,
    messages: list[dict[str, Any]],
    *,
    timeout: float | None = None,
    max_context_chars: int = 120_000,
    max_context_tokens: int | None = None,
    char_per_token: int = 3,
    http_client: httpx.AsyncClient | None = None,
    stream_callback: StreamCallback | None = None,
) -> str:
    """
    Отправляет ``messages`` в OpenRouter; перебирает ``free_models`` до успеха.

    Если задан ``stream_callback``, сначала для каждой модели пробуется SSE; при неудаче — обычный POST.
    """
    if _estimate_messages_chars(messages) > max_context_chars:
        logger.warning("OpenRouter: context too long (%s chars), aborting", max_context_chars)
        raise RuntimeError("context_too_long")

    if max_context_tokens is not None:
        est = estimate_messages_prompt_tokens(
            messages,
            settings=settings,
            char_per_token=char_per_token,
        )
        if est > max_context_tokens:
            logger.warning(
                "OpenRouter: estimated prompt tokens %s > limit %s",
                est,
                max_context_tokens,
            )
            raise RuntimeError("context_too_long_tokens")

    t = timeout if timeout is not None else settings.openrouter_timeout_sec

    async with _http_client_scope(http_client) as client:
        for model in settings.free_models:
            try:
                if stream_callback is not None:
                    content = await _post_chat_completion_stream(
                        client, settings, model, messages, timeout=t, stream_callback=stream_callback
                    )
                    if content:
                        return content
                content = await _post_chat_completion(client, settings, model, messages, timeout=t)
                if content is not None:
                    if stream_callback is not None:
                        await stream_callback(content, True)
                    return content
            except Exception:
                logger.exception("OpenRouter model=%s request failed", model)
                continue

    raise RuntimeError("openrouter_unavailable")


async def ask_ai_text(
    settings: Settings,
    prompt: str,
    *,
    timeout_override: float | None = None,
    http_client: httpx.AsyncClient | None = None,
) -> str:
    """Короткий вызов system+user; внутри тот же ``max_tokens`` и лимиты длины, что и в чате."""
    try:
        system = (
            f"Ты — ассистент {settings.bot_name}. Отвечай по-русски, кратко и по делу. "
            "Не приписывай этому боту функции вроде «аркана дня», Human Design, натальных карт "
            "и подобного: реальные возможности продукта — нейротекст, изображения, оживление фото, "
            "видео, музыка и помощь с текстовым промптом для картинки. "
            "Если пользователь сам просит эзотерику как тему для текста — обсуждай как обычную тему, "
            "но не выдавай это за встроенные разделы бота."
        )
        messages: list[dict[str, str]] = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]
        return await ask_ai_messages(
            settings,
            messages,
            timeout=timeout_override,
            max_context_chars=50_000,
            max_context_tokens=16_000,
            http_client=http_client,
        )
    except RuntimeError as e:
        if str(e) in ("context_too_long", "context_too_long_tokens"):
            return "Запрос слишком длинный. Сократите текст и попробуйте снова."
        logger.error("ask_ai_text: all models failed or unavailable")
        return "Сервис временно недоступен. Попробуйте через минуту."
    except Exception:
        logger.exception("ask_ai_text unexpected error")
        return "Сервис временно недоступен. Попробуйте через минуту."
